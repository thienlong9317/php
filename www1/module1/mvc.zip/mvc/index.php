<?php 
$action  =  $_GET['action']??'index';
$controllername  =  ($_GET['controller']??'hethong').'controller';
$path = 'controller/'.$controllername.'.php';
if(file_exists($path))
{
    include $path;
    $controller = new $controllername();
    if(method_exists($controller,$action))
    {
        $controller->$action();
    }else{
        $controller->_404();
    }
}else{
    include 'controller/hethongcontroller.php';
    $controller = new hethongcontroller();
    $controller->_404();
}