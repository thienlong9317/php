<?php 
class hethongcontroller
{
    function index()
    {
        include 'view/hethong/index.php';
    }
    function contact()
    {
        include 'view/hethong/lienhe.php';
    }
    function _404()
    {
        include 'view/hethong/404.php';
    }
}